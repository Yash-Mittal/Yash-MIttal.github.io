%function that returns the scale space as described in the David Lowe paper 

function scaleSpace=scaleSpace(image, octaves, scales)

	grayScaleIm = rgb2gray(image);
	grayScaleIm = double(grayScaleIm)/double(255.0); 

	%firstBlurSigma = 0.5; 
	kernelSize = 15; 

	%step 1: double the image size prior to building the first level of the pyramid 

	%initialBluredImage = gaussianBlur(grayScaleIm,firstBlurSigma,kernelSize);
    inDSI = imresize(grayScaleIm, 2, 'bilinear'); %grayScaleIm; %imresize(grayScaleIm, 2, 'bilinear');
	initialDoubleSizeImage = inDSI;

%	initialDoubleSizeImage = gaussianBlur(initialDoubleSizeImage,1,kernelSize);



	%sigma = 1.6
	initialSigma = sqrt(2); %1.6; %sqrt(2); 
%    initialSigma = 1.6; 
	currentSigma = initialSigma; 

	totScales = scales + 3; 
	cellOctaves = cell(octaves,1);
	previousDoubleSizeImage = initialDoubleSizeImage ;
    
    %this matrix will contain the values of accumulated sigmas and will be
    %used to calculate orientation histogram weight later on 
    accumSigmas = zeros(octaves, totScales); 
    
    for octave = 1:octaves
		sigma = zeros(size(initialDoubleSizeImage,1), size(initialDoubleSizeImage,2), size(initialDoubleSizeImage,3), totScales);
		cellOctaves{octave} = sigma;
		%it is done for 5 blur levels 
		for blur_level = 1:totScales
            %method used to calculate accum sigmas was taken from http://mathworld.wolfram.com/Convolution.html
            if (octave==1 && blur_level == 1)
                accumSigmas(octave,blur_level) = sqrt(((0.5*2)^2) +(currentSigma^2));
            elseif (blur_level == 1)
                accumSigmas(octave,blur_level) = sqrt(((accumSigmas(octave-1,3)/2)^2) ...
                    +(currentSigma^2));
            else
                accumSigmas(octave,blur_level) = sqrt((accumSigmas(octave,blur_level-1)^2) ...
                    +(currentSigma^2));
            end
			k = (2^((blur_level)/scales));
			bluredImage = gaussianBlur(previousDoubleSizeImage,currentSigma,kernelSize);
			previousDoubleSizeImage = bluredImage;
			disp(['Octave ' num2str(octave) ' blur level ' num2str(blur_level) '  sigma ' num2str(currentSigma)]);

			cellOctaves{octave}(:, :, :, blur_level) = bluredImage; 
			currentSigma  = initialSigma * k; 
		end 
%		cellOctaves{octave} = uint8(cellOctaves{octave}); 

		currentSigma = initialSigma; 
		initialDoubleSizeImage = reduceInHalf(cellOctaves{octave}(:,:,:,totScales-3)); %imresize(initialDoubleSizeImage, 0.5, 'bilinear'); %reduceInHalf(cellOctaves{octave}(:,:,:,3)); %imresize(initialDoubleSizeImage, 0.5, 'bilinear');
		previousDoubleSizeImage = initialDoubleSizeImage; 
    end 
    
    returnData = cell(2,1); 
    
    
    returnData{1} = cellOctaves; 
    returnData{2} = accumSigmas; 

	scaleSpace = returnData; 

	function reduceInHalf = reduceInHalf(image)
		reduceInHalf=image(1:2:end,1:2:end) ;	
	end 
end