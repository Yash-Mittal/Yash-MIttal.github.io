This folder conatins matlab code for corner detection using harris algorithm.
The folder also contains implemenation of feature detectors, descriptors and matching based on algorithm described in Lowe's paper.
The codes are written in Matlab.
You can execute the complete work by siftDescriptor.m
For corner detection, execute harris.m separately.
Comments are added to codes to enhance readability.
Input images are in "images" folder.
Output images after matching are in "output" folder.