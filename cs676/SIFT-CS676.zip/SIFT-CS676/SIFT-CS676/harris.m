clear;
clc;
im = imread('images.jpg');
imgb = rgb2gray(im);
hs = fspecial('sobel');
ix = imfilter(imgb,hs,'same');
iy = imfilter(imgb,hs','same');
sigma=1;
%sg = 3*sigma;
hg = fspecial('gaussian',[3 3],sigma);
sx2 = imfilter(ix.*ix,hg,'same');
sy2 = imfilter(iy.*iy,hg,'same');
sxy = imfilter(ix.*iy,hg,'same');
k = 0.04;
r = (sx2.*sy2 - sxy.*sxy) - (k*((sx2+sy2).^2));
markerInserter = vision.MarkerInserter('Shape','X-mark','Size',5,'BorderColor','Custom','CustomBorderColor',uint8([0 0 255]));
pts=zeros([size(imgb,1)*size(imgb,2),2]);
l = 1;
for i = 1:size(imgb,1)
    for j = 1:size(imgb,2)
        if r(i,j)>=245
            pts(l,1) = j;
            pts(l,2) = i;
            l = l+1;
        end
    end
end
im = step(markerInserter, im, int32(pts));
figure;
imshow(im);
title('Original image with corners.');